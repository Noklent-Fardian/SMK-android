package com.example.mytambah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText edtAngka1;
    private EditText edtAngka2;
    private TextView txtHasil;
    private Button btnCek, btnBantuan;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtAngka1 = findViewById(R.id.Edtangka1);
        edtAngka2= findViewById(R.id.Edtangka2);
        txtHasil = findViewById(R.id.show_result);
        btnCek = findViewById(R.id.button_result);
        btnBantuan=findViewById(R.id.button_bantuan);

        btnCek.setOnClickListener(this);
        btnBantuan.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId()==R.id.button_bantuan){
            Toast toast=Toast.makeText(getApplicationContext(),"Maaf Bantuan Belum tersedia saat ini",Toast.LENGTH_SHORT);
            toast.show();
        }
        if(view.getId()==R.id.button_result){
            String InputAngka1 =edtAngka1.getText().toString().trim();
            String InputAngka2 =edtAngka2.getText().toString().trim();

            boolean isEmptyFields=false;
            boolean isInvalidDouble=false;
            if (TextUtils.isEmpty(InputAngka1)){
                isEmptyFields=true;
                edtAngka1.setError("Field ini tidak boleh kosong");
            }
            if (TextUtils.isEmpty(InputAngka2)){
                isEmptyFields=true;
                edtAngka2.setError("Field ini tidak boleh kosong");
        }
            Double Operand1 = toDouble(InputAngka1);
            Double Operand2 = toDouble(InputAngka2);

            if(Operand1 == null){
                isInvalidDouble=true;
                edtAngka1.setError("Harus berupa Angka");
            }
            if(Operand2 == null){
                isInvalidDouble=true;
                edtAngka2.setError("Harus berupa Angka");
            }
            if(!isEmptyFields&&!isInvalidDouble){
                double hasil = Operand1+Operand2;
                txtHasil.setText(String.valueOf(hasil));
            }

    }
}

    private Double toDouble(String str) {
        try{
            return Double.valueOf(str);
        } catch (NumberFormatException e){
            return null;
        }
    }
    }